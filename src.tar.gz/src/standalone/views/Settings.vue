<template>
  <div>
    Settings
  </div>
</template>

<script>

export default {
  name: 'Settings',
}
</script>
