<template>
  <div>
    Contacts
  </div>
</template>

<script>

export default {
  name: 'Contacts',
}
</script>
